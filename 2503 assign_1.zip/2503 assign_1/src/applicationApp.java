import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class applicationApp  {

	public static Employee newEmp;
	public static ProcessingDetails manager;
	
	public static void main(String args[]) throws FileNotFoundException {
		
		manager = new ProcessingDetails();
		
		newEmp =  new Employee("Shawn", "Seafood", 'S',  201693648, 78000, 168);
		
		System.out.println("Gross pay: " + manager.calcGrossPay( 25));
		System.out.println("net pay: " + manager.calcNetPay( 25));
		
		manager.printDetail();
	}
}
