/**
* <The Employee class describes the different employees that a particular organization has. For Fly By
Night Consulting Company, there are three types of employees: salary, hourly, and consultants.>
* @author <Shawn Tian>
* @version 1.0
* Last Modified: <sep 26, 2022> - <action> <Shawn Tian>
*/


public class Employee {

	private int empNo;
	private String empName;
	private String depart;
	private char type;
	private double payRate;
	private int maxHour;
	
  public Employee() {
    	
		this.empNo = 0;
		this.maxHour = 0;
		this.payRate = 0;
		this.empName = "null";
		this.depart="null";
		this.type=' ';
	}
  public Employee( String name, String department, char empType,int number, double pay, int hour) {
	  
	  this.empName= name;
	  this.depart=department;
	  this.empNo=number;
	  this.type=empType;
	  this.payRate=pay;
	  this.maxHour=hour;
    }
  public Employee(Employee newEmp, int empNo, String empName, String department) {
    	this.type = newEmp.type;
    	this.payRate=newEmp.payRate;
    	this.maxHour = newEmp.maxHour;
    	empNo = newEmp.getEmpNo();
    	empName = newEmp.getEmpName();
    	department = newEmp.getDepartment();
    	
    }
  
  
  /**
  * <This method set a new employee name.>
  * @param <newName> <a new name>
  * < newName>
  */ 
  public void setEmpName(String newName){
	  
	  this.empName=newName;
  }
  /**
   * <This method set a new department name.>
   * @param <newDepart> <a new department name>
   * < newDepart>
   */ 
   public void setDepartment(String newDepart){
 	  
 	  this.depart=newDepart;
   }
   /**
    * <This method set a new pay rate.>
    * @param <newPayRate> <a new pay rate.>
    * < newPayRate>
    */ 
    public void setPayRate(double newPayRate){
  	  
  	  this.payRate=newPayRate;
    }
    
   /**
    * <This method set a new employee  type of employee. ‘S’ for salary, ‘H’ for hourly,
    * ‘C’ for Consultant.>
    * @param <newEmpType> <a new char type of employee 'S' ‘H’ for hourly,
    * ‘C’ for Consultant.>>
    * < newEmpType>
    */
   public void setType(char newEmpType) {
 	  
 	  this.type = newEmpType;
   }
  /**
   * <This method set a new employee number.>
   * @param <newNo> <a one line description of the parameter>
   * < newNo>
   */
  public void setEmpNo(int newNo) {
	  
	  this.empNo = newNo;
  }
  /**
   * <This method will return the char type of the employee.>
   * @return <a description of what is returned, including if errors are
   returned>
   */
   public char getEmpType() {
 	  
 	  return type;
   }
  /**
  * <This method will return the employee's name.>
  * @return <a description of what is returned, including if errors are
  returned>
  */
  public String getEmpName() {
	  
	  return empName;
  }
  /**
  * <This method will return the employee's number.>
  * @return < Employee number is a integer that act as a identification >
  */
  public int getEmpNo() {
	  
	  return empNo;
  }
  /**
   * <This method will return the employee's department.>
   * @return < A department is a String that details the work place of the employee.>
   */
  public String getDepartment() {
	  
	  return depart;
  }
  /**
   * <This method will return the employee's payRate.>
   * @return <pay rate is the amount of money the employee get paid per hour.>
   */
  public double getPayRate() {
	  
	  return payRate;
  }
  /**
   * <a description of what the method does>
   * @return <a description of what is returned, including if errors are
   returned>
   */
  public int getMaxHour() {
	  
	  return maxHour;
  }
}
