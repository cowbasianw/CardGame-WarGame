import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class ProcessingDetails extends applicationApp{
	
    private final String FILE_PATH = "src/Employee test Data.txt";
	
	public File DB ;
	public ArrayList<Employee> empList;
	
	Scanner c = new Scanner(System.in);
	
	public ProcessingDetails()throws FileNotFoundException{
	  
	  empList = new ArrayList();
	
	}
	
    
    	
    
   /** 
	*<this method calculates the gross pay of a employee>
	*<hoursWorked> <the numbers of hour the employee is going to work.> 
	*< hoursWorked>
	*<return the gross pay, the amount of money the employee has earned without 
	*the deductions. possible error would be that there is no information of the 
	*employee.>
	*/
	public double calcGrossPay( int hoursWorked) {
		
		double grossPay;
		int maxHour;
		
		 grossPay = 0;
		switch(newEmp.getEmpType()) {
		  case 'S':
		   
			  double annuelSalary;
			  
			  maxHour = 168;
			  annuelSalary = newEmp.getPayRate();
			  
			  
			  
			  grossPay= annuelSalary/52;
			  
		    break;
		    
		  case 'H':
		    
			  double extraPay;
			  if(hoursWorked == 40 ) {
				  
				  grossPay = newEmp.getPayRate()* 40;
				  
			  }
			  
			  else if ((hoursWorked>40)&&(hoursWorked<=60)) {
				  
				  int extraHours = hoursWorked -40;
				  double newHourWage = newEmp.getPayRate()*1.5;
				   extraPay = newHourWage * extraHours;
				   
				   grossPay = newEmp.getPayRate()* 40 + extraPay;
			  }
			  
			  if(hoursWorked > 60) {
				  int extraHours  = 20;
				  double newHourWage = newEmp.getPayRate()*1.5;
				   extraPay = newHourWage * extraHours;
				  
				   grossPay = newEmp.getPayRate()* 40 + extraPay;
				  
			  }
			  
			  
		    break;
		    
		  case 'C':
			  
			  System.out.println("Enter the maximum number of hours per week determine at the time of the signing of the contract.");
			  maxHour = c.nextInt();
			  
			  if(hoursWorked <= maxHour) {
				  
				  grossPay = newEmp.getPayRate()* hoursWorked;
				  
			  }
			  
			  else {
				  
				  grossPay = newEmp.getPayRate()* maxHour;
			  }
			  
			break; 
		}  
		
		return grossPay;
	}
	
	  /** 
		*<this method calculates the Income Withholding Tax of a employee>
		*<grossPay> <the amount of money the employee has earned without 
	    *the deductions> 
		*< grossPay>
		*<this method returns the the deductions from the gross pay of the employee, possible >
		*/
		public double calcWithhold (double grossPay) {
			
			double feduralTax; 
			
			if (grossPay < 1000) {
				feduralTax = grossPay * 0.075;
			}
			
			else if (grossPay >= 1000 && grossPay < 2000) {
				feduralTax = grossPay * 0.12;
			}
			
			else {
				feduralTax = grossPay * 0.17;
			}
			
			return feduralTax;
		}
	  /** 
		*<this method calculates the Canada Pension Plan (CPP) contribution
		*of a employee>
		*<grossPay> <the amount of money the employee has earned without 
	    *the deductions> 
		*< grossPay>
		*<CCP equals 4.75% of gross weekly pay, will get errors if 
		*there is no gross pay>
		*/
		public double calcCPP(double grossPay) {
			
			double CPP = 0.0475 * grossPay;
			
			return CPP;
			
		}
	  /** 
		*<this method calculates the Employment Insurance (EI) contribution
		* of a employee>
		*<grossPay> <the amount of money the employee has earned without 
	    *the deductions> 
		*< grossPay>
		*<EI equals to 1.8% of gross weekly pay. It will get errors if 
		*there is no gross pay>
		*/
		public double calcEI(double grossPay) {
			double EI = 0.018 * grossPay;
			
			return EI;
		}
		 /** 
		*<this method calculates Extended Health Benefit of a employee>
		*<grossPay> <the amount of money the employee has earned without 
	    *the deductions>
		*< grossPay>
		*<a description of what is returned, including if errors are 
		*returned>
		*/
		public double calcExtHealth(double grossPay) {
			double healthBenefit = 0.013 *grossPay;
			
			return healthBenefit;
		}
		 /** 
		*<this method calculates the union dues of a employee>
		*<grossPay> <a one line description of the parameter> 
		*< grossPay>
		*<this returns the union due,, which is 1.3% of the gross pay. It will error if 
		*there is no gross pay.>
		*/
		public double calcUnionDues(double grossPay){
			double unionDues = 0.01 *  grossPay;
			
			return unionDues;
		}
		 /** 
		*<this method calculates the gross pay of a employee>
		*<hoursWorked> <a one line description of the parameter> 
		*< hoursWorked>
		*<a description of what is returned, including if errors are 
		*returned>
		*/
		public double calcNetPay(int hoursWorked ) {
			
			double netPay;
			double grossPay;
			
			
			
			netPay =0;
			grossPay = calcGrossPay(hoursWorked);
			
			switch(newEmp.getEmpType()) {
			  case 'S':
				  
				  netPay = grossPay - calcWithhold(grossPay) - calcCPP(grossPay) - calcEI(grossPay)
				  - calcExtHealth(grossPay);
				  
				  
				  break;
				  
			  case 'H':
				  
				  netPay = grossPay - calcWithhold(grossPay) - calcCPP(grossPay) - calcEI(grossPay)
				  - calcExtHealth(grossPay)- calcUnionDues(grossPay);
				 
				  break;
			
			  case 'C':
				  
				  netPay = grossPay - calcWithhold(grossPay) - calcCPP(grossPay) - calcEI(grossPay);
				  
				  break;
				  
				  }
			return netPay; 
			
		}
		
	
		 /** 
		*<this method compares a employee's number with another employee and return 
		*conditions base on the numbers>
		*<other> <another employee object> 
		*< other>
		*<return condition based on the the employee number being compared to.
		*will get error if employee number does not match the conditions set.>
		*/
	    public int compareTo (Employee other) {
		
		int condition = 9;
		
		if(newEmp.getEmpNo()< other.getEmpNo()) {
			
			condition = -1;
		}
		
		else if (newEmp.getEmpNo()== other.getEmpNo()) {
			
			condition = 0;
		}
		
		else if (newEmp.getEmpNo()> other.getEmpNo()) {
			condition = 1;
		}
		return condition;
	    }
	    /**
	     *  <This method print out all the information of the employee.>
	     *  
	     *  
	     * 
	     */
	    public void printDetail() {
		
		String empType = "null";
		
		switch(newEmp.getEmpType()) {
		  case 'S':
		   
			  empType = "Salary";
			  
		    break;
		    
		  case 'H':
		    
			  empType = "Hourly";
		    break;
		    
		  case 'C':
			  
			  empType = "Consultants";
			break; 
		}  
		
		System.out.println();
		System.out.printf("Employee Number: %15s %n", newEmp.getEmpNo() );
		System.out.println();
		System.out.printf("Employee Name: %13s %n", newEmp.getEmpName() );
		System.out.println();
		System.out.printf("Employee Type: %14s %n", empType );
		System.out.println();
		System.out.printf("Employee department: %9s %n", newEmp.getDepartment());
		System.out.println();
		System.out.printf("Employee pay rate: %10s %n", newEmp.getPayRate());
		System.out.println();
		System.out.printf("Employee net pay: %11s %n", calcNetPay(newEmp.getMaxHour()));
		
		
		
		
	}
    
	
}
